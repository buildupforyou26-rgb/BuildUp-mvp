# BuildUp — Unified MVP v6

This is the cumulative, scope-locked BuildUp MVP rebuilt from the v5 source rather than a replacement demo.

## Product scope retained + expanded
- Pidgin-first, voice-first onboarding direction.
- 4-step onboarding: Tell Us → Occupation → Email signup → selected builder.
- Email-only MVP authentication; phone OTP is excluded.
- Professional pathway with profile builder and ATS-friendly CV builder/preview.
- Artisan/provider pathway with occupation selection, Capability Card builder, live preview and max 5 work photos.
- Capability Card save → dashboard flow.
- Workfolio structure, Vouches and Bronze/Silver/Gold milestones.
- Marketplace discovery with relevance-first ranking, then availability, trust tier and vouch count.
- Gold 50+, Silver 20+, Bronze 10+.
- Customer needs / gigs surface in discovery and Tool Guide.
- Tool Guide: vouch, Skill Bite and customer needs/gigs actions.
- Skill Bites library + admin CMS; admin publish state is persisted into the same frontend content source for the MVP.
- Optional multi-profile support under one account.
- Settings with Light / Dark / System theme.
- WhatsApp share links for Capability Cards and vouch requests.
- Supplied light/dark splash assets retained.

## Design lock
- One shared token system.
- Restrained navy/teal palette.
- No arbitrary button/hover colors.
- Consistent focus states, whitespace, borders, radius and typography.
- Mobile-first and accessible touch targets.
- No unnecessary gradients, visual noise or generic AI-dashboard styling.

## MVP implementation note
This v6 is intentionally frontend-first with local persistence so the full UX can be exercised without phone OTP, SMS, or a backend dependency. Production services (auth, storage, AI transcription, CV generation, marketplace data, notifications) can be connected behind these stable flows without redesigning the core journeys.

## Run
npm install
npm run dev
