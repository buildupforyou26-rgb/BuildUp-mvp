import React,{useEffect,useState} from 'react';
import {createRoot} from 'react-dom/client';
import './styles.css';

const load=(key,fallback)=>{try{return JSON.parse(localStorage.getItem(key))??fallback}catch{return fallback}};
const I=({name,size=20})=>{const p={back:'M19 12H5m6-6-6 6 6 6'}[name]||'';return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d={p}/></svg>};

function AdminCMS(){
    const[bites,setBites]=useState(()=>load('buildup_skill_bites',[]));
    const[title,setTitle]=useState('');const[category,setCategory]=useState('Career Growth');const[duration,setDuration]=useState('02:00');
    const publish=()=>{if(!title.trim())return;const newBite={id:'b'+Date.now(),title,category,duration,description:'New Skill Bite published by BuildUp admin.',published:true};const updated=[newBite,...bites];setBites(updated);localStorage.setItem('buildup_skill_bites',JSON.stringify(updated));setTitle('')};
    return <main className="container narrow"><p className="eyebrow">ADMIN CMS</p><h2>Skill Bites</h2>
        <section className="form"><h3>New Skill Bite</h3><label>TITLE</label><input value={title} onChange={e=>setTitle(e.target.value)} placeholder="e.g. How to earn your first vouch"/><label>CATEGORY</label><select value={category} onChange={e=>setCategory(e.target.value)}><option>Career Growth</option><option>Business Growth</option><option>Trust & Reputation</option></select><label>DURATION</label><input value={duration} onChange={e=>setDuration(e.target.value)} placeholder="02:30"/><button className="btn primary full" onClick={publish}>Publish now</button></section>
        <section><h3>Live content</h3>{bites.map(b=><div className="admin-row" key={b.id}><div><strong>{b.title}</strong><span>{b.category} · {b.duration}</span></div><button className={b.published?'status live':'status'} onClick={()=>{const updated=bites.map(x=>x.id===b.id?{...x,published:!x.published}:x);setBites(updated);localStorage.setItem('buildup_skill_bites',JSON.stringify(updated))}}>{b.published?'Published':'Draft'}</button></div>)}</section>
    </main>
}

createRoot(document.getElementById('root')).render(<AdminCMS/>);